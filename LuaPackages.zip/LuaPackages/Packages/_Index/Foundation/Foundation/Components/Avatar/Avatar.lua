local Foundation = script:FindFirstAncestor("Foundation")
local Packages = Foundation.Parent

local React = require(Packages.React)

local Dash = require(Packages.Dash)

local Flags = require(Foundation.Utility.Flags)
local Image = require(Foundation.Components.Image)
local StatusIndicator = require(Foundation.Components.StatusIndicator)
local Types = require(Foundation.Components.Types)
local View = require(Foundation.Components.View)
local mapBindable = require(Foundation.Utility.mapBindable)
local withCommonProps = require(Foundation.Utility.withCommonProps)
local withDefaults = require(Foundation.Utility.withDefaults)

local ThumbnailSize = require(Foundation.Enums.ThumbnailSize)
local ThumbnailType = require(Foundation.Enums.ThumbnailType)
local getRbxThumb = require(Foundation.Utility.getRbxThumb)

local useAvatarVariants = require(script.Parent.useAvatarVariants)
local useTokens = require(Foundation.Providers.Style.useTokens)
local usePresentationContext = require(Foundation.Providers.Style.PresentationContext).usePresentationContext

local AvatarSize = require(Foundation.Enums.AvatarSize)
type AvatarSize = AvatarSize.AvatarSize
local UserPresence = require(Foundation.Enums.UserPresence)
type UserPresence = UserPresence.UserPresence

local getAvatarSize = require(script.Parent.getAvatarSize)
type Bindable<T> = Types.Bindable<T>

export type AvatarProps = {
	-- Roblox user id
	userId: Bindable<number>,
	backgroundStyle: Types.ColorStyle?,
	backplateStyle: Types.ColorStyle?,
	size: AvatarSize?,
	userPresence: UserPresence?,
	-- When true, requests the thumbnail service to composite the user's
	-- equipped profile frame into the headshot server-side.
	includeProfileFrame: boolean?,
} & Types.CommonProps

local defaultProps = {
	size = AvatarSize.Medium,
	userPresence = UserPresence.None :: UserPresence,
	testId = "--foundation-avatar",
}

local function Avatar(avatarProps: AvatarProps, ref: React.Ref<GuiObject>?)
	local props = withDefaults(avatarProps, defaultProps)
	local tokens = useTokens()
	local presentationContext = usePresentationContext()

	local variantProps =
		useAvatarVariants(tokens, props.size, props.userPresence, props.backplateStyle, presentationContext.isIconSize)
	local size = getAvatarSize(tokens, props.size, presentationContext.isIconSize)

	return React.createElement(
		View,
		withCommonProps(props, {
			tag = variantProps.container.tag,
			ref = ref,
			backgroundStyle = variantProps.container.backgroundStyle,
			stroke = variantProps.container.stroke,
			Size = UDim2.fromOffset(size, size),
		}),
		{
			Image = React.createElement(Image, {
				Image = mapBindable(props.userId, function(userId)
					return getRbxThumb(
						ThumbnailType.AvatarHeadShot,
						userId,
						ThumbnailSize.Medium,
						{ includeProfileFrame = props.includeProfileFrame }
					)
				end),
				tag = variantProps.avatar.tag,
				backgroundStyle = props.backgroundStyle,
				testId = `{props.testId}--image`,
			}),
			Indicator = if variantProps.statusIndicator.isVisible
				then if Flags.FoundationStatusIndicatorMask
					then React.createElement(StatusIndicator, {
						testId = `{props.testId}--status-indicator`,
						variant = variantProps.statusIndicator.variant,
						shape = variantProps.statusIndicator.shape,
						size = variantProps.statusIndicator.size,
						mask = variantProps.statusIndicatorMask.mask,
						ZIndex = variantProps.statusIndicatorMask.ZIndex,
						AnchorPoint = variantProps.statusIndicatorMask.AnchorPoint,
						Position = variantProps.statusIndicatorMask.Position,
					})
					else React.createElement(
						View,
						Dash.join(variantProps.statusIndicatorBackplate, {
							testId = `{props.testId}--indicator-backplate`,
						}),
						React.createElement(StatusIndicator, {
							testId = `{props.testId}--status-indicator`,
							variant = variantProps.statusIndicator.variant,
							shape = variantProps.statusIndicator.shape,
							size = variantProps.statusIndicator.size,
						})
					)
				else nil,
		}
	)
end

return React.memo(React.forwardRef(Avatar))
